(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','http://www.google-analytics.com/analytics.js','ga');

// --------------------------------------
// ~~ API EasyAnalytics ~~
// trackingId : The Google property Id
// sends referrer and campaign args automatically
// --------------------------------------
function trackerWithTrackingId(trackingId, clientId){
	ga('create', trackingId, { 'clientId': clientId, 'alwaysSendReferrer': false, 'allowAnchor': false});
	ga('require', 'ecommerce', 'ecommerce.js');
	
	//ga('set', 'appName', 'WebApp');
	//ga('set', 'appVersion', '1.0');
}

// --------------------------------------
// Custom Dimensions
// index(int) : The index of the custom dimension defintion. This index is 1-based.
// dimension(string) : The value of the custom dimension.
// --------------------------------------
function setCustomDimension(index, dimension){
	ga('set', 'dimension'+index, dimension);
}

// --------------------------------------
// Custom Metrics
// index(int) : The index of the custom metric definition.
// metric(int) : The value of the custom metric, interpreted as a 64-bit integer. Values can be negative.
// --------------------------------------
function setCustomMetric(index, metric){
	ga('set', 'metric'+index , metric);
}

// --------------------------------------
// Event Tracking
// category(string) : The category of the event, ex : "UI_Action"
// action(string) : The action related to the event, ex : "Button_pressed"
// label(string) : The name button responsible of this event
// aValue(int) : The event value if any
// --------------------------------------
function sendEventWith(category, action, label, aValue){
	ga('send', 'event', {
  	'eventCategory': category,
  	'eventAction': action,
  	'eventLabel': label,
  	'eventValue': aValue
});
}

// --------------------------------------
// Screen Tracking
// page : The page name, ex : "/gawrapper"
// --------------------------------------
function sendView(page){
	ga('send', 'pageview', {
  		'page': page 
  	});
}

// --------------------------------------
// Sessions
// startSession : Indicates when the session starts and ends
// --------------------------------------
function setStartSession(startSession){
	if (startSession) {
		ga('set', 'sessionControl', 'start');
	} else {
		ga('set', 'sessionControl', 'end');
	}
	
}

// --------------------------------------
// Crashes & Exceptions
// description (Optional) : a description of the exception (up to 100 characters). Accepts null .
// fatal : indicates whether the exception was fatal. true indicates fatal.
// --------------------------------------
function sendException(description, fatal){
	ga('send', 'exception', { 'exDescription': description, 'exFatal': fatal });
}

// --------------------------------------
// Social Interactions
// network : represents the social network with which the user is interacting (e.g. Google+, Facebook, Twitter, etc.).
// action : represents the social action taken (e.g. Like, Share, +1, etc.).
// target (optional) : represents the content on which the social action is being taken (i.e. a specific article or video).
// --------------------------------------
function sendSocial(network, action, target){
	ga('send', 'social', network, action, target);
}

// --------------------------------------
// User Timings
// category : the category of the timed event
// intervalInMilliseconds : the timing measurement in milliseconds
// nameStr (Optional) : the name of the timed event
// Label (Optional) : the label of the timed event
// --------------------------------------
function sendTiming(category, intervalInMilliseconds, nameStr, label){
	ga('send', 'timing', category, nameStr, intervalInMilliseconds, label);
}

// --------------------------------------
// Ecommerce Tracking
// transactionId : Transaction Id, should be unique.
// orderTotal : Order total (in micros)
// affiliation : Affiliation
// totalTax : Total tax (in micros)
// totalShipping : Total shipping cost (in micros)
// currencyCode : Set currency code For the complete list of supported currencies and currency codes, see the Supported Currencies Reference.
// productSKU : Product SKU
// productName : Product name
// productPrice : Product price (in micros)
// quantity : Product quantity
// productCategory : Product category
// --------------------------------------
function sendTransaction(transactionId,
               orderTotal,
               affiliation,
               totalTax,
               totalShipping,
               currencyCode,
               productSKU,
               productName,
               productPrice,
               quantity,
               productCategory){
               
	ga('ecommerce:clear');
               
	ga('ecommerce:addTransaction', {
  		'id': transactionId,                    					// Transaction ID. Required.
  		'affiliation': affiliation,   								// Affiliation or store name.
  		'revenue': (orderTotal/1000000).toFixed(2),               	// Grand Total.
  		'shipping': (totalShipping/1000000).toFixed(2),             // Shipping.
  		'tax': (totalTax/1000000).toFixed(2)                     	// Tax.
	});

	ga('ecommerce:addItem', {
  		'id': transactionId,                    					// Transaction ID. Required.
  		'name': productName,    									// Product name. Required.
  		'sku': productSKU,                 							// SKU/code.
  		'category': productCategory,         						// Category or variation.
  		'price': (productPrice/1000000).toFixed(2),                 // Unit price.
  		'quantity': quantity,                    					// Quantity.
  		'currencyCode': currencyCode 								// local currency code.
	});

	ga('ecommerce:send');
}               
               
               
// --------------------------------------
// Campaigns
// campaignUrl : the campaign url. Be careful, on iOS only it has to be a well formatted url such as "http://www.anyname.com?utm_campaign=my_campaign&utm_source=google&utm_medium=cpc&utm_term=my_keyword&utm_content=ad_variation1"
// --------------------------------------              
function setCampaignUrl(campaignUrl){

	var params = campaignUrl.substring(campaignUrl.indexOf('?'));
	var reg=new RegExp("[&]+", "g");
	var paramsArr=params.split(reg);
	for (var i=0; i<paramsArr.length; i++) {
 		var param = paramsArr[i];
 		var reg=new RegExp("[=]+", "g");
		var argsArr=param.split(reg);
		
		if (argsArr[0] == 'utm_campaign') {
			ga('set', 'campaignName', argsArr[1]);
		} else if (argsArr[0] == 'utm_source') {
			ga('set', 'campaignSource', argsArr[1]);
		} else if (argsArr[0] == 'utm_medium') {
			ga('set', 'campaignMedium', argsArr[1]);
		} else if (argsArr[0] == 'utm_term') {
			ga('set', 'campaignKeyword', argsArr[1]);
		} else if (argsArr[0] == 'utm_content') {
			ga('set', 'campaignContent', argsArr[1]);
		} 
	}
}

// --------------------------------------
// Referrer
// url : the referree url
// --------------------------------------
function setReferrer(url){
	ga('set', 'referrer', url);
}

// --------------------------------------
// Dispatch period
// seconds : the dispatch period in seconds
// --------------------------------------
function setDispatchPeriod(seconds){
	//does not exists
}

// --------------------------------------
// Manual dispatch
// --------------------------------------
function disptach(){
	//does not exists
}



